library(testthat)

GTF <- GTF.tool::load_annotation("tests/test_anno.gtf")

# 1️⃣ Test create_GTF_df
test_that("create_GTF_df zwraca poprawny obiekt", {
  GTF2 <- GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000)
  expect_s3_class(GTF2, "data.frame")
  expect_true(all(c("seqname", "feature", "start", "end") %in% colnames(GTF2)))
  expect_gt(nrow(GTF2), 0)
})

# 2️⃣ Test add_CDS
test_that("add_CDS dodaje CDS poprawnie", {
  GTF2 <- GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000)
  GTF3 <- GTF.tool::add_CDS(GTF2)
  expect_s3_class(GTF3, "data.frame")
  expect_true(any(GTF3$feature == "CDS"))
})

# 3️⃣ Test add_introns
test_that("add_introns dodaje introny", {
  GTF2 <- GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000)
  GTF3 <- GTF.tool::add_CDS(GTF2)
  GTF4 <- GTF.tool::add_introns(GTF3)
  expect_true(any(GTF4$feature == "intron"))
})

# 4️⃣ Test add_UTR
test_that("add_UTR dodaje regiony UTR", {
  GTF4 <- GTF.tool::add_introns(GTF.tool::add_CDS(GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000)))
  GTF5 <- GTF.tool::add_UTR(GTF4, five_prime_utr = 300, three_prime_utr = 800)
  expect_true(any(GTF5$feature %in% c("five_prime_utr", "three_prime_utr")))
})

# 5️⃣ Test create_full_GTF
test_that("create_full_GTF tworzy pełną adnotację", {
  GTF5 <- GTF.tool::add_UTR(GTF.tool::add_introns(GTF.tool::add_CDS(GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000))),
    five_prime_utr = 300, three_prime_utr = 800
  )
  GTF6 <- GTF.tool::create_full_GTF(GTF5)
  expect_s3_class(GTF6, "data.frame")
  expect_gt(nrow(GTF6), nrow(GTF5))
})

# 6️⃣ Test create_reduced_GTF
test_that("create_reduced_GTF tworzy zredukowaną wersję GTF", {
  GTF5 <- GTF.tool::add_UTR(GTF.tool::add_introns(GTF.tool::add_CDS(GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000))),
    five_prime_utr = 300, three_prime_utr = 800
  )
  GTF7 <- GTF.tool::create_reduced_GTF(GTF5)
  expect_s3_class(GTF7, "data.frame")
  expect_lt(nrow(GTF7), nrow(GTF5))
})

# 7️⃣ Test refflat_create
test_that("refflat_create działa poprawnie", {
  GTF5 <- GTF.tool::add_UTR(GTF.tool::add_introns(GTF.tool::add_CDS(GTF.tool::create_GTF_df(GTF, optimize = TRUE, shift = 100000))),
    five_prime_utr = 300, three_prime_utr = 800
  )
  ref_flat <- refflat_create(GTF5)
  expect_s3_class(ref_flat, "data.frame")
  expect_true(all(c("geneName", "name", "chrom") %in% colnames(ref_flat)))
})
